package prueba.eva62muy.servicios_motocicleta;



import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import prueba.eva62muy.DaoMotocicleta.DaoMotocicleta;
import prueba.eva62muy.modelo.Motocicleta;

@Path("motocicleta")
public class GestionServicioMotocicleta {
	@Inject
	DaoMotocicleta daoMotocicleta;
	
	
	@GET
	@Path("saludo")
	public String saludo() {
		return "Hola mundo";
	}
	
	
	@GET
	@Path("seleccionarTodos")
	@Produces(MediaType.APPLICATION_JSON)
	public java.util.List<Motocicleta> list(){
		return daoMotocicleta.getAll();
	}
	
	
	@POST	
	@Produces("application/json")
	@Consumes("application/json")
	public Response guardarMotocicleta(Motocicleta motocicleta) {
		try {
			daoMotocicleta.guardarMotocicleta(motocicleta);
			return Response.status(Response.Status.OK).entity(motocicleta).build();
		}catch(Exception e){
			
			
			return Response.status(Response.Status.OK).entity(e).build();
		}
	}
}
