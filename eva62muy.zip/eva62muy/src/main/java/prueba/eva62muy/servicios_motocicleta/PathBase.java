package prueba.eva62muy.servicios_motocicleta;


import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("rs")
public class PathBase extends Application{

}
