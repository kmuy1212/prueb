package prueba.eva62muy.negocio;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.inject.Inject;
import prueba.eva62muy.DaoMotocicleta.DaoMotocicleta;
import prueba.eva62muy.modelo.Motocicleta;

@Singleton
@Startup
public class DemoDao {
	@Inject
	private DaoMotocicleta daoMotocicleta;
	
	@PostConstruct
	public void init() {
		System.out.println("conectando");
		
		Motocicleta motocicleta=new Motocicleta();
		motocicleta.setId(1);
		motocicleta.setMatricula("abe10");
		motocicleta.setCilindraje("250c");
		motocicleta.setModelo("pulsar");
		daoMotocicleta.guardarMotocicleta(motocicleta);
	}
}
