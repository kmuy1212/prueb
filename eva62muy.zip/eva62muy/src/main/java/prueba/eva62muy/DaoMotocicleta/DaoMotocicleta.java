package prueba.eva62muy.DaoMotocicleta;

import java.util.List;


import jakarta.ejb.Stateless;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import prueba.eva62muy.modelo.Motocicleta;

@Stateless
public class DaoMotocicleta {
  @PersistenceContext
  private EntityManager em;
  
  
  public void guardarMotocicleta(Motocicleta motocicleta) {
	  em.persist(motocicleta);
	  
  }
  
  
  public void update(Motocicleta motocicleta) {
		em.merge(motocicleta);
	}
	
	public Motocicleta read(String matricula) {
		Motocicleta p = em.find(Motocicleta.class, matricula);
		return p;
	}
	
	public void delete(String matricula) {
		Motocicleta p = em.find(Motocicleta.class, matricula);
		em.remove(p);
	}
	
	public List<Motocicleta> getAll(){
		String jpql = "SELECT p FROM Motocicleta p";
		Query q = em.createQuery(jpql);
		return q.getResultList();
	}
}
