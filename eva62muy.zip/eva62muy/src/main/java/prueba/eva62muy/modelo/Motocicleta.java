package prueba.eva62muy.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Motocicleta {
	@Id
	private int id;
	private String matricula;
	private String cilindraje;
	private String modelo;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getCilindraje() {
		return cilindraje;
	}
	public void setCilindraje(String cilindraje) {
		this.cilindraje = cilindraje;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	
}
